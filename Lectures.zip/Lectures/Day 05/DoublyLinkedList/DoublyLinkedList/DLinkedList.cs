﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkedList
{
    internal class DLinkedList
    {
        private Node head;
        private Node tail;

        public DLinkedList()
        {
            head = null;
            tail = null;
        }

    }

    
}
