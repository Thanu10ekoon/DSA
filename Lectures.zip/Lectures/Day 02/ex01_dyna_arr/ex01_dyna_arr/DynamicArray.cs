﻿using System;
using System.Collections.Generic;

namespace ex01_dyna_arr //instead we can use namespace ex01_dyna_arr; too 
{
    public class DynamicArray   //just like public, private & .. in c++ here we have public,internal..
    {
        private int[] data;     //reference value
        private int capacity;   //integer
        private int count;      //integer
        
        //constructor
        public DynamicArray()
        {
            count = 0;
            capacity = 4;
            data = new int[capacity];
        }

        //an public method
        public void print()
        {
            if (count > 0)
            {
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine($"{data[i]}");
                }
                Console.WriteLine();
            }
            if(count == 0)
            {
                Console.WriteLine("Empty Dataset");
                return;
            }
        }

        public void add(int k)
        {
            if (count <capacity) 
            {
                data[count] = k;
                count++;
            }
           

        }
    }
}