﻿using ex01_dyna_arr;

DynamicArray array1 =  new DynamicArray();
array1.print();