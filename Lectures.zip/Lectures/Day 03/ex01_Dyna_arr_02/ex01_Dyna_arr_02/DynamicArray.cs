﻿using Microsoft.VisualBasic.FileIO;
using System.Security.Cryptography.X509Certificates;

public class DArray
{
    private int[] data;
    private int count;
    private int capacity;
    
    public DArray()
    {
        count = 0;
        capacity = 4;
        data = new int[capacity];
    }

    public void Add(int item)
    {
        if (count < capacity)
        {
            data[count] = item;
            count++;
        }
        else if (count == capacity) 
        {
            /*int[] data2 = new int[capacity*2];
            for (int i = 0; i < count; i++) 
            {
                data2[i] = data[i];
            }
            data2[count] = item;
            capacity = capacity * 2;
            count++;
            data = data2;*/

            //instead of above conventional for loop use 'Copy' function provided in new method Expand
            Expand();
            data[count] = item;
            count++;
        }
    }

    public void Expand()
    {
        capacity = capacity * 2;
        int[] newData = new int[capacity];
        Array.Copy(data, newData, count);
        data = newData;
    }
    public void print()
    {
        if (count > 0)
        {
            for (int i = 0; i < count; i++)
            {
                Console.Write($"{data[i]} ");
            }
            Console.WriteLine();
        }
        else if (count == 0)
        {
            Console.WriteLine("Empty");
        }
    }

    public void RemoveAt(int index)
    {
        if (count < capacity / 4) 
        {
            Shrink();
        }
        if(index < 0 || index >= count) 
        {
            return;
        }

        for (int i = index; i < count - 1; i++) 
        {
            data[i] = data[i + 1];
        }
        count--;
        
    }   

    public void Shrink() 
    {
        capacity = capacity / 2;
        int[] newData = new int[capacity];
        Array.Copy(data, newData, count);
        data = newData;
    }

}











































































/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex01_Dyna_arr_02
{
    internal class DynamicArray
    {
    }
}
*/