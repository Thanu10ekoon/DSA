﻿DArray array;

array = new DArray();

array.Add(5);
array.Add(6);
array.Add(5);
array.Add(6);
array.Add(10);
array.Add(11);
array.print();
Console.WriteLine();
array.RemoveAt(3);

array.print();