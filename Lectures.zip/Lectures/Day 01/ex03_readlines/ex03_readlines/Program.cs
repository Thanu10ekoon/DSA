﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("NUmer Reader and reWriter");
//int num1 = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine($"Entered Num = {num1}");

Console.WriteLine("Enter a Number between 1-100");
int N = Convert.ToInt32(Console.ReadLine());

//For loop to print in new lines
for(int x = 1; x <= N; x++)
{
    double ans = x / 2.0;
    Console.WriteLine($"{x} / 2.0 = {ans}");
}

Console.WriteLine();

//For loop to print on same line
for (int x = 1; x <= N; x++)
{
    double ans = x / 2.0;
    Console.Write($"{ans}, ");
}

Console.WriteLine();