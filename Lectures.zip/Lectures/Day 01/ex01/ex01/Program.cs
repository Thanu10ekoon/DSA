﻿Console.Write("Num: ");
int num = Convert.ToInt32(Console.ReadLine());

int[] nums = new int[num];

for (int i = 0; i < nums.Length; i++)
{
    nums[i] = i + 1;
    Console.WriteLine($"{nums[i]+1} / 2 = {nums[i]/2.0}");
}