﻿int[] nums = new int[5];

for (int i = 0; i < 5; i++)
{
    nums[i] = i+1;
}

for (int i = 0;i < nums.Length; i++)
{
    if(i!= nums.Length-1)
    {
        Console.Write($"{nums[i]}, ");
    }
    else
    {
        Console.Write(nums[i]);
    }
}