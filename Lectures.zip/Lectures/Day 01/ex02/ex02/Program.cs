﻿int x = 10;
Console.WriteLine(x);

//Formatting Strings
Console.WriteLine($"x={x}");