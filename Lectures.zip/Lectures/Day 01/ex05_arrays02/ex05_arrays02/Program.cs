﻿//0
/*Console.Write("Enter your name here: ");
string userName = Console.ReadLine();
Console.WriteLine($"Name:{userName} ");*/

//1
/*string[] strin_1 = new string[5];

for (int i = 0; i < strin_1.Length; i++)
{
    strin_1[i] = Console.ReadLine();
}

for  (int i = 0; i < strin_1.Length; i++)
{
    Console.Write(strin_1[i]);
}*/

//2
/*int[] B = { 1, 2, 3 };    //if not working use int[] B = [ 1, 2, 3 ];

Console.WriteLine($"Size of Array B = {B.Length}");
*/


//3
using System.Runtime.CompilerServices;

int[] nums = { 1, 2, 4, 8, 9, 15 };

int sum = 0;
for(int i = 0; i < nums.Length; i++) 
{
    sum = sum + nums[i];
}

Console.WriteLine($"Sum = {sum}");