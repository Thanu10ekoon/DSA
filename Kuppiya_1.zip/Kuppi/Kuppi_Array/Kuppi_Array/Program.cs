﻿int[] nums = new int[10];

for (int i = 0; i < 15; i++)
{
    nums[i] = (i+1)*5;
}