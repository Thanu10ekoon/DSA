﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Info_System
{
    public class Car
    {
        public string make;
        public string model;
        public int reg_no;

        public Car() 
        {
            make = "Unknown";
            model = "Unknown2";
            reg_no = 0;
        }

    }
}
