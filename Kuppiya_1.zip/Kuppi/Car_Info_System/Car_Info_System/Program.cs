﻿using Car_Info_System;

Car[] cars = new Car[100];

for(int i = 0; i < 100; i++)
{
    cars[i] = new Car();
    cars[i].make = "Toyota";
    cars[i].model = "Corolla";
    cars[i].reg_no = i+1;
}

for(int i = 0; i < 100; i++)
{
    if(i < 9) 
    {
        Console.WriteLine($"CBF-000{cars[i].reg_no} ");
    }
    else if(i>9 && i < 99)
    {
        Console.WriteLine($"CBF-00{cars[i].reg_no} ");
    }
     
}