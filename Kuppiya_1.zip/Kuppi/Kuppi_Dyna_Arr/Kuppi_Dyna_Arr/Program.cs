﻿using Kuppi_Dyna_Arr;

Dynamic_Array arr1;
arr1 = new Dynamic_Array();

arr1.Add(1);
arr1.Add(2);
arr1.Add(3);
arr1.Add(4);
arr1.Add(5);

Console.WriteLine("Before Adding 6th element");
for (int i = 0; i < arr1.capacity; i++)
{
    Console.WriteLine(arr1.arr[i]);
}

arr1.Add(6);
Console.WriteLine("After Adding 6th element");
for (int i = 0; i < arr1.counter; i++)
{
    Console.WriteLine(arr1.arr[i]);
}
//1 2 3 4 5 6 VALUES    arr
//0 1 2 3 4 5 INDEX = i
arr1.remove(3);
Console.WriteLine("After Removing element 3");

for (int i = 0; i < arr1.counter; i++)
{
    Console.WriteLine(arr1.arr[i]);
}