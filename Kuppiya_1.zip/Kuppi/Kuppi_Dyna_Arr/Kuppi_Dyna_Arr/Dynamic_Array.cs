﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kuppi_Dyna_Arr
{
    public class Dynamic_Array
    {
        public int capacity;
        public int[] arr;
        public int counter;

        public Dynamic_Array()
        {
            capacity = 5;
            arr = new int[capacity];
            counter = 0;
        }

        public void Add(int item) 
        {
            if(counter < capacity) 
            {
                arr[counter] = item;
                counter++;
            }
            else 
            {
                capacity = capacity*2;
                int[] temp = new int[capacity];
                for (int i = 0; i < counter; i++)
                {
                    temp[i] = arr[i];
                }
                temp[counter] = item;
                arr = temp;
                counter++;
            }
        }

        public void remove(int item) 
        {
            if (counter < capacity / 4) 
            {
                capacity = capacity / 2;
            }

            for(int i=0;i < counter; i++) 
            {
                if (arr[i] == item)
                {
                    counter--;
                    for (int j = i; j < counter; j++)
                    {
                        arr[j] = arr[j + 1];
                    }
                }
            }
        }

    }
}
